class CLIError(Exception):
    pass

class SourceError(Exception):
	pass